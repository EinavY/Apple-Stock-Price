# Apple-stock-price-prediction
Watch this Video to understand the flow! 
https://youtu.be/puNj1wQSdpk

We will predict the stock value of Apple 

the main module calls all the other modules and have access to all the functions that are needed 
for building the stock model
the main three modules are:
1. get_data()- using this module for getting the last stock price and the history prices.


2. data_preparation()- using this module to prepare the data for the ML models by fixing the types of columns 
fixing the stock splits issue and more.


3. model_lstm()- predict the stock value and is the main ML model in this project.
